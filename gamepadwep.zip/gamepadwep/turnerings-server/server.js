const express = require('express');
const app = express();
const path = require('path');
const fs = require('fs');

// Middleware til at parse JSON-data fra anmodninger
app.use(express.json());

// Sti til turneringsvisning.html
const turneringsVisningPath = path.join(__dirname, '../turneringsvisning.html');

// Håndtering af anmodningen om turneringsvisning.html
app.get('/', (req, res) => {
  res.sendFile(turneringsVisningPath);
});

// Hent spillere fra spillere.json
app.get('/spillere', (req, res) => {
  const jsonData = fs.readFileSync('spillere.json');
  const spillere = JSON.parse(jsonData).spillere;
  res.json(spillere);
});

// Opret en ny spiller
app.post('/spillere', (req, res) => {
  const { navn, nummer } = req.body;

  if (!navn || !nummer) {
    res.status(400).send('Både navn og nummer er påkrævet.');
    return;
  }

  const spillereData = JSON.parse(fs.readFileSync('spillere.json'));
  const nySpiller = { navn, nummer };
  spillereData.spillere.push(nySpiller);
  fs.writeFileSync('spillere.json', JSON.stringify(spillereData, null, 2));

  res.status(201).json(nySpiller);
});

app.listen(3000, () => {
  console.log('Serveren kører på http://localhost:3000');
});
