// Globale variabler til at holde styr på spillere i turneringen
const turneringSpillere = new Map(); // Bruger Map i stedet for Set for at gemme nummer sammen med navn

// Fetch spillere og vis dem i "Spillere" tabellen
fetch('turnerings-server/spillere.json')
  .then(response => {
    if (!response.ok) {
      throw new Error('Fejl ved indlæsning af spillere.json');
    }
    return response.json();
  })
  .then(data => {
    const spillere = data.spillere;
    const playerList = document.getElementById('player-list');
    const turneringSpillereTable = document.getElementById('turnering-spillere-table');

    spillere.forEach(spiller => {
      const newRow = playerList.insertRow();
      const navnCell = newRow.insertCell();
      navnCell.textContent = spiller.navn;
      const nummerCell = newRow.insertCell();
      nummerCell.textContent = spiller.nummer; // Viser nummer i "Spillere" tabellen

      newRow.addEventListener('click', () => {
        if (turneringSpillere.has(spiller.navn)) {
          turneringSpillere.delete(spiller.navn);
          updateTurneringSpillereTable();
        } else {
          turneringSpillere.set(spiller.navn, spiller.nummer);
          updateTurneringSpillereTable();
        }
      });
    });

    function updateTurneringSpillereTable() {
      const tbody = turneringSpillereTable.getElementsByTagName('tbody')[0];
      tbody.innerHTML = ''; // Nulstil tabellen

      turneringSpillere.forEach((nummer, spillerNavn) => {
        const newRow = tbody.insertRow();
        const navnCell = newRow.insertCell();
        navnCell.textContent = spillerNavn;
        const nummerCell = newRow.insertCell();
        nummerCell.textContent = nummer; // Viser nummer i "Turnering" tabellen

        newRow.addEventListener('click', () => {
          turneringSpillere.delete(spillerNavn);
          updateTurneringSpillereTable();
        });
      });
    }
  })
  .catch(error => console.log('Fejl: ' + error));

// Start turneringen
const startTurneringButton = document.getElementById('start-turnering');
startTurneringButton.addEventListener('click', () => {
  const turneringSpillereTable = document.getElementById('turnering-spillere-table');
  const tbody = turneringSpillereTable.getElementsByTagName('tbody')[0];
  const antalSpillere = tbody.rows.length;

  if (antalSpillere >= 2) {
    // Start turneringen, når der er mindst 2 spillere i tabellen
    console.log('Turneringen er startet med ' + antalSpillere + ' spillere!');
    // Her kan du tilføje din egen logik til at starte turneringen
  } else {
    alert('Der skal være mindst 2 spillere for at starte turneringen!');
  }
});

// Søgefunktion til at filtrere spillere i tabellen
const searchInput = document.getElementById('search-input');
searchInput.addEventListener('input', () => {
  const searchQuery = searchInput.value.toLowerCase();
  const playerList = document.getElementById('player-list');
  const rows = playerList.getElementsByTagName('tr');

  for (let i = 0; i < rows.length; i++) {
    const playerName = rows[i].getElementsByTagName('td')[0].textContent.toLowerCase();
    const playerNumber = rows[i].getElementsByTagName('td')[1].textContent.toLowerCase();
    const displayStyle = playerName.includes(searchQuery) || playerNumber.includes(searchQuery) ? '' : 'none';
    rows[i].style.display = displayStyle;
  }
});

// Find login-popup vinduet og knappen til at åbne det
const loginPopup = document.getElementById('login-popup');
const loginButton = document.getElementById('add-player-button');

// Find knappen til at lukke login-popup vinduet
const closeLoginButton = document.getElementById('close-login-popup');

// Åbn login-popup vinduet, når der klikkes på Tilføj spiller knappen
loginButton.addEventListener('click', () => {
  loginPopup.style.display = 'block';
});

// Luk login-popup vinduet, når der klikkes på Annuller knappen
closeLoginButton.addEventListener('click', () => {
  loginPopup.style.display = 'none';
});

// Find login-knappen og tilføj en event listener til at logge ind
const loginSubmitButton = document.getElementById('login-submit');
loginSubmitButton.addEventListener('click', () => {
  const usernameInput = document.getElementById('username');
  const passwordInput = document.getElementById('password');
  const username = usernameInput.value.trim();
  const password = passwordInput.value.trim();

  // Her skal du tilføje din egen logik til at validere brugernavn og kodeord
  // For eksempel kan du bruge en server-side autentificering med en database af brugernavne og kodeord

  // Hvis brugernavn og kodeord er korrekte, vises pop-up-vinduet til at tilføje en spiller
  if (username === 'brugernavn' && password === 'kodeord') {
    loginPopup.style.display = 'none';
    showAddPlayerPopup(); // Vis pop-up-vinduet til at tilføje en spiller
  } else {
    alert('Forkert brugernavn eller kodeord. Prøv igen.');
  }
});

// Funktion til at vise pop-up-vinduet til at tilføje en spiller
function showAddPlayerPopup() {
  popup.style.display = 'block';
}

// Find pop-up vinduet til at tilføje en spiller og knappen til at lukke det
const popup = document.getElementById('popup');
const closeButton = document.getElementById('close-popup');

// Luk pop-up vinduet, når der klikkes på Annuller knappen
closeButton.addEventListener('click', () => {
  popup.style.display = 'none';
});

// Find tilføj spiller knappen i pop-up vinduet
const addPlayerSubmitButton = document.getElementById('add-player-submit');

// Tilføj event listener til tilføj spiller knappen
addPlayerSubmitButton.addEventListener('click', () => {
  const playerNameInput = document.getElementById('player-name');
  const playerNumberInput = document.getElementById('player-number');
  const playerName = playerNameInput.value.trim();
  const playerNumber = playerNumberInput.value.trim();

  if (playerName !== '' && playerNumber !== '') {
    // Opret et nyt spillerobjekt med navnet og nummeret
    const newPlayer = {
      navn: playerName,
      nummer: playerNumber,
    };

    // Tilføj spilleren til spillerlisten i HTML
    const playerList = document.getElementById('player-list');
    const tableRow = document.createElement('tr');
    const nameCell = document.createElement('td');
    nameCell.textContent = newPlayer.navn;
    tableRow.appendChild(nameCell);
    const numberCell = document.createElement('td');
    numberCell.textContent = newPlayer.nummer;
    tableRow.appendChild(numberCell);
    playerList.appendChild(tableRow);

    // Luk pop-up-vinduet
    popup.style.display = 'none';

    // Send den nye spiller til serveren (her skal du tilpasse endpoint og fetch-metode)
    fetch('/spillere', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(newPlayer),
    })
      .then(response => response.json())
      .then(data => console.log('Spiller tilføjet:', data))
      .catch(error => console.error('Fejl ved tilføjelse af spiller:', error));
  }
});

// Funktion til at generere et 7-cifret tilfældigt nummer
function generateRandomNumber() {
  return Math.floor(1000000 + Math.random() * 9000000);
}

// ... (din tidligere JavaScript-kode) ...

// ... (resten af din tidligere JavaScript-kode) ...
